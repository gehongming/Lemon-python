# 2：完成1-10的整数数字相加，并打印最后的结果
sum=0
for i in range(1,11):
     sum=sum+i
print(sum)